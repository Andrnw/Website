<?php
echo "<pre>";
print_r($_POST);
echo "<pre>";

$message_sent = false;


if(isset($_POST['btn-send']){
    
    $userName = $_POST['name'];
    $userFirm = $_POST['firma'];
    $userEmail = $_POST['email'];
    $userPhone = $_POST['phone'];
    $userMessage = $_POST['message'];
    
    
 if(empty($userName) || empty($userEmail) || empty($userPhone) || empty($userMessage)){
     header('location:index.html?error');
 }else{
     $to = "andreialexandrescu7@gmail.com";

     if(mail($to,$userEmail,$userName,$userMessage,$userPhone)){
         header("location:index.html?success");
     }
 }
    
}else{
    header("location:index.html");
}






?>